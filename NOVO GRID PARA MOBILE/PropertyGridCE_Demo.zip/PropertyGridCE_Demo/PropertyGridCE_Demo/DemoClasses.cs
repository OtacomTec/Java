﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;  // required for attributes
using System.Reflection;
using System.Windows.Forms;
using System.Drawing;

namespace PropertyGridCE_Demo
{
    // Simple sample class with properties of several types
    public class Person
    {
        public enum Gender { Male, Female }

        #region private fields
        private string[] _Names = new string[3];
        private Gender _Gender;
        private DateTime _BirthDate;
        private int _Income;
        private System.Guid _Guid;
        #endregion

        #region Public Properties
        [Category("Name")]
        [DisplayName("First Name")]
        public string FirstName
        {
            set { _Names[0] = value; }
            get { return _Names[0]; }
        }

        [Category("Name")]
        [DisplayName("Mid Name")]
        public string MidName
        {
            set { _Names[1] = value; }
            get { return _Names[1]; }
        }

        [Category("Name")]
        [DisplayName("Last Name")]
        public string LastName
        {
            set { _Names[2] = value; }
            get { return _Names[2]; }
        }

        [Category("Characteristics")]
        [DisplayName("Gender")]
        public Gender PersonGender
        {
            set { _Gender = value; }
            get { return _Gender; }
        }

        [Category("Characteristics")]
        [DisplayName("Birth Date")]
        public DateTime BirthDate
        {
            set { _BirthDate = value; }
            get { return _BirthDate; }
        }

        [Category("Characteristics")]
        public int Income
        {
            set { _Income = value; }
            get { return _Income; }
        }   // simple property, no attributes needed

        [DisplayName("GUID"), ReadOnly(true), ParenthesizePropertyName(true)]   // many attributes defined
        public string GuidStr
        {
            get { return _Guid.ToString(); }
        }

        [Browsable(false)]  // this property will not be displayed
        public System.Guid Guid
        {
            get { return _Guid; }
        }
        #endregion

        public Person()
        {
            // default values
            for (int i = 0; i < 3; i++)
                _Names[i] = "";
            _Gender = Gender.Male;
            _Guid = System.Guid.NewGuid();
        }
        public override string ToString()
        {
            return string.Format("{0} {1} {2}", FirstName, MidName, LastName).Trim().Replace("  ", " ");
        }
    }

    // Sample class with custom properties
    public class Vehicle : PropertyGridCE.ICustomProperties
    {
        public enum CarType { Sedan, StationWagon, Coupe, Roadster, Van, Pickup, Truck } 
        public enum CarBrand { Acura, Audi, BMW, Citroen, Ford, GMC, Honda, Lexus, Mercedes, Mitsubishi, Nissan, Porshe, Suzuki, Toyota, VW, Volvo }

        #region Private fields
        private CarBrand _Brand;
        private CarType _CarType;
        private string _Model;
        private int _Year;
        private string _Plate;
        private int _Seats;
        private int _Volume;
        private int _Payload;
        #endregion

        #region Public Properties
        [Category("Classification")]
        public CarBrand Brand
        {
            get { return _Brand; }
            set { _Brand = value; }
        }

        [Category("Classification")]
        [ParenthesizePropertyName(true)]
        [DisplayName("Type")]
        public CarType TypeOfCar
        {
            get { return _CarType; }
            set { _CarType = value; }
        }

        [Category("Classification")]
        public string Model
        {
            get { return _Model; }
            set { _Model = value; }
        }

        [Category("Identification")]
        [DisplayName("Manuf.Year")]
        public int Year
        {
            get { return _Year; }
            set { _Year = value; }
        }

        [Category("Identification")]
        [DisplayName("License Plate")]
        public string Plate
        {
            get { return _Plate; }
            set { _Plate = value; }
        }

        [Category("Capacity")]
        public int Seats
        {
            get { return _Seats; }
            set { _Seats = value; }
        }

        // Just for Pickup and Truck
        [Category("Capacity")]
        [DisplayName("Volume (ft3)")]
        public int Volume
        {
            get { return _Volume; }
            set { _Volume = value; }
        }

        [Category("Capacity")]
        [DisplayName("Payload (pnd)")]
        public int Payload
        {
            get { return _Payload; }
            set { _Payload = value; }
        }
        #endregion

        #region ICustomProperties Members
        PropertyInfo[] PropertyGridCE.ICustomProperties.GetProperties()
        {
            List<PropertyInfo> props = new List<PropertyInfo>();

            foreach (System.Reflection.PropertyInfo info in GetType().GetProperties())
            {
                if ((info.Name == "Volume" || info.Name == "Payload") && (this._CarType != CarType.Pickup && this._CarType != CarType.Truck))
                    continue;

                props.Add(info);
            }
            return props.ToArray();
        }
        #endregion
    }

    // Sample class with properties with custom editors
    public class Place
    {
        [CustomEditor(typeof(CountryEditor))]
        public struct CountryInfo
        {
            public enum Continent { Africa = 1, America = 2, Asia = 3, Europe = 4, Oceania = 5 }

            public static readonly CountryInfo[] Countries = {
                // African countries
                new CountryInfo( 1, "AO", "ANGOLA" ),
                new CountryInfo( 1, "CM", "CAMEROON" ),
                // American countries
                new CountryInfo( 2, "BO", "BOLIVIA" ),
                new CountryInfo( 2, "PE", "PERU" ),
                // Asian countries
                new CountryInfo( 3, "JP", "JAPAN" ),
                new CountryInfo( 3, "MN", "MONGOLIA" ),
                // European countries
                new CountryInfo( 4, "DE", "GERMANY" ),
                new CountryInfo( 4, "NL", "NETHERLANDS" ),
                // Oceanian countries
                new CountryInfo( 5, "AU", "AUSTRALIA" ),
                new CountryInfo( 5, "NZ", "NEW ZEALAND" )
            };

            public Continent Contin;
            public string Abrev;
            public string Name;

            public override string  ToString()
            {
                 return Name;
            }
            public CountryInfo(int _continent, string _abrev, string _name)
            {
                this.Contin = (Continent)_continent;
                this.Abrev = _abrev;
                this.Name = _name;
            }
        }

        #region Private fields
        private string[] _Address = new string[4];
        public CountryInfo _Country;
        private Image _Picture;
        public int _CurrentValue;
        public int _Floors;
        #endregion

        #region Public properties
        [Category("Address")]
        public string Street
        {
            get { return _Address[0]; }
            set { _Address[0] = value; }
        }
        [Category("Address")]
        public string City
        {
            get { return _Address[1]; }
            set { _Address[1] = value; }
        }
        [Category("Address")]
        public string Province
        {
            get { return _Address[2]; }
            set { _Address[2] = value; }
        }
        [Category("Address")]
        public string Postal
        {
            get { return _Address[3]; }
            set { _Address[3] = value; }
        }
        [Category("Address")]
        public CountryInfo Country
        {
            get { return _Country; }
            set { _Country = value; }
        }

        [Category("Characteristics")]
        [CustomEditor(typeof(PictureEditor))]
        public Image Picture
        {
            get { return _Picture; }
            set { _Picture = value; }
        }
        [Category("Characteristics")]
        public int Floors
        {
            get { return _Floors; }
            set { _Floors = value; }
        }
        [Category("Characteristics")]
        public int CurrentValue
        {
            get { return _CurrentValue; }
            set { _CurrentValue = value; }
        }
        #endregion

        public Place()
        {
            for (int i = 0; i < _Address.Length; i++)
                _Address[i] = "";
        }
    }
}
