﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Reflection;

namespace PropertyGridCE_Demo
{
    public partial class CountryEditor : UserControl, PropertyGridCE.ICustomEditor
    {
        #region Private fields
        private Place.CountryInfo Info;

        private EventHandlerList ValueChangedColl = new EventHandlerList();
        private EventArgs EventArguments = new EventArgs();
        private object ID = new object();
        #endregion

        public CountryEditor()
        {
            InitializeComponent();
        }

        #region ICustomEditor Members
        event EventHandler PropertyGridCE.ICustomEditor.ValueChanged
        {
            add { ValueChangedColl.AddHandler(ID, value); }
            remove { ValueChangedColl.RemoveHandler(ID, value); }
        }
        PropertyGridCE.EditorStyle PropertyGridCE.ICustomEditor.Style
        {
            get { return PropertyGridCE.EditorStyle.DropDown; }
        }
        object PropertyGridCE.ICustomEditor.Value
        {
            get { return Info; }
            set
            {
                if (value is Place.CountryInfo)
                {
                    Info = (Place.CountryInfo)value;
                    this.ComboContinent.SelectedItem = Info.Contin;
                    this.ComboCountry.SelectedItem = Info;
                }
            }
        }
        void PropertyGridCE.ICustomEditor.Init(Rectangle rect)
        {
            this.Location = rect.Location;

            ComboContinent.Items.Clear();
            foreach (FieldInfo info in typeof(Place.CountryInfo.Continent).GetFields(BindingFlags.Public | BindingFlags.Static))
            {
                ComboContinent.Items.Add(Enum.Parse(typeof(Place.CountryInfo.Continent), info.Name, false));
            }
            ComboContinent.SelectedIndex = 0;

            ComboContinent.SelectedIndexChanged += new EventHandler(ComboContinent_SelectedIndexChanged);
            ComboCountry.SelectedIndexChanged += new EventHandler(ComboCountry_SelectedIndexChanged);
        }
        #endregion

        #region Control events
        void ComboContinent_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboCountry.BeginUpdate();
            ComboCountry.Items.Clear();
            Info.Contin = (Place.CountryInfo.Continent)ComboContinent.SelectedItem;
            foreach (Place.CountryInfo country in Place.CountryInfo.Countries)
            {
                if (country.Contin == Info.Contin)
                    ComboCountry.Items.Add(country);
            }
            ComboCountry.SelectedIndex = 0;
            ComboCountry.EndUpdate();

            InvokeEvents();
        }
        void ComboCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            Info = (Place.CountryInfo)ComboCountry.SelectedItem;

            InvokeEvents();
        }
        #endregion

        #region Private methods
        private void InvokeEvents()
        {
            Delegate d1 = ValueChangedColl[ID];

            if (d1 != null)
            {
                Delegate[] list = d1.GetInvocationList();

                if (list != null)
                    foreach (Delegate d2 in list)
                        d2.Method.Invoke(d2.Target, new object[] { this, this.EventArguments });
            }
        }
        #endregion

        private void CountryEditor_LostFocus(object sender, EventArgs e)
        {
            if (!this.Focused && !ComboContinent.Focused && !ComboCountry.Focused)
                this.Parent.Focus();
        }
    }
}
