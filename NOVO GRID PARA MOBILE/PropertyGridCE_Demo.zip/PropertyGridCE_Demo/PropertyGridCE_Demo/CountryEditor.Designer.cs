﻿namespace PropertyGridCE_Demo
{
    partial class CountryEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.ComboContinent = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ComboCountry = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.label1.Location = new System.Drawing.Point(3, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 20);
            this.label1.Text = "Continent:";
            // 
            // ComboContinent
            // 
            this.ComboContinent.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.ComboContinent.Location = new System.Drawing.Point(62, 10);
            this.ComboContinent.Name = "ComboContinent";
            this.ComboContinent.Size = new System.Drawing.Size(117, 20);
            this.ComboContinent.TabIndex = 1;
            this.ComboContinent.LostFocus += new System.EventHandler(this.CountryEditor_LostFocus);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.label2.Location = new System.Drawing.Point(3, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 20);
            this.label2.Text = "Country:";
            // 
            // ComboCountry
            // 
            this.ComboCountry.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.ComboCountry.Location = new System.Drawing.Point(62, 39);
            this.ComboCountry.Name = "ComboCountry";
            this.ComboCountry.Size = new System.Drawing.Size(117, 20);
            this.ComboCountry.TabIndex = 4;
            this.ComboCountry.LostFocus += new System.EventHandler(this.CountryEditor_LostFocus);
            // 
            // CountryEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.ComboCountry);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ComboContinent);
            this.Controls.Add(this.label1);
            this.Name = "CountryEditor";
            this.Size = new System.Drawing.Size(185, 70);
            this.LostFocus += new System.EventHandler(this.CountryEditor_LostFocus);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox ComboContinent;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox ComboCountry;

    }
}
