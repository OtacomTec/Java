﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PropertyGridCE_Demo
{
    public partial class PictureEditor : Form, PropertyGridCE.ICustomEditor
    {
        #region Private fields
        private EventHandlerList ValueChangedColl = new EventHandlerList();
        private EventArgs EventArguments = new EventArgs();
        private object ID = new object();
        private Size PictureBoxSize;
        #endregion

        public PictureEditor()
        {
            InitializeComponent();
        }

        #region ICustomEditor Members
        event EventHandler PropertyGridCE.ICustomEditor.ValueChanged
        {
            add { ValueChangedColl.AddHandler(ID, value); }
            remove { ValueChangedColl.RemoveHandler(ID, value); }
        }
        PropertyGridCE.EditorStyle PropertyGridCE.ICustomEditor.Style
        {
            get { return PropertyGridCE.EditorStyle.Modal; }
        }
        object PropertyGridCE.ICustomEditor.Value
        {
            get { return PictureBox1.Image; }
            set
            {
                PictureBox1.Image = (Image)value;
                ScaleView();
            }
        }
        void PropertyGridCE.ICustomEditor.Init(Rectangle rect)
        {
            PictureBoxSize = PictureBox1.Size;
        }
        #endregion

        #region Control events
        private void ButtonOk_Click(object sender, EventArgs e)
        {
            InvokeEvents();
            DialogResult = DialogResult.OK;
            this.Close();
        }
        private void ButtonCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }
        private void ButtonClear_Click(object sender, EventArgs e)
        {
            ClearPicture();
        }
        private void DocumentList1_DocumentActivated(object sender, Microsoft.WindowsCE.Forms.DocumentListEventArgs e)
        {
            try
            {
                ClearPicture();
                Bitmap bmp = new Bitmap(e.Path);
                PictureBox1.Image = (Image)bmp.Clone();
                ScaleView();
                bmp.Dispose();
            }
            catch
            {
                PictureBox1.Image = null;
            }
        }
        #endregion

        #region Private methods
        private void InvokeEvents()
        {
            Delegate d1 = ValueChangedColl[ID];

            if (d1 != null)
            {
                Delegate[] list = d1.GetInvocationList();

                if (list != null)
                    foreach (Delegate d2 in list)
                        d2.Method.Invoke(d2.Target, new object[] { this, this.EventArguments });
            }
        }
        private void ClearPicture()
        {
            if (PictureBox1.Image != null)
            {
                PictureBox1.Image.Dispose();
                PictureBox1.Image = null;
            }
        }
        private void ScaleView()
        {
            if (PictureBox1.Image == null)
                return;
            float scale = Math.Min(Math.Min((float)PictureBoxSize.Height / PictureBox1.Image.Height, (float)PictureBoxSize.Width / PictureBox1.Image.Width), 1.0f);
            PictureBox1.Size = new Size((int)(PictureBox1.Image.Width * scale), (int)(PictureBox1.Image.Height * scale));
        }
        #endregion
    }
}
