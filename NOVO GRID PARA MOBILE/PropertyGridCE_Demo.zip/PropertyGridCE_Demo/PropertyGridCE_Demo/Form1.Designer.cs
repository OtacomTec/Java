﻿namespace PropertyGridCE_Demo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ButtonPerson = new System.Windows.Forms.Button();
            this.ButtonVehicle = new System.Windows.Forms.Button();
            this.ButtonPlace = new System.Windows.Forms.Button();
            this.propertyGrid1 = new System.Windows.Forms.PropertyGridCE();
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.SuspendLayout();
            // 
            // ButtonPerson
            // 
            this.ButtonPerson.Location = new System.Drawing.Point(11, 10);
            this.ButtonPerson.Name = "ButtonPerson";
            this.ButtonPerson.Size = new System.Drawing.Size(57, 20);
            this.ButtonPerson.TabIndex = 0;
            this.ButtonPerson.Text = "Person";
            this.ButtonPerson.Click += new System.EventHandler(this.ButtonPerson_Click);
            // 
            // ButtonVehicle
            // 
            this.ButtonVehicle.Location = new System.Drawing.Point(74, 10);
            this.ButtonVehicle.Name = "ButtonVehicle";
            this.ButtonVehicle.Size = new System.Drawing.Size(57, 20);
            this.ButtonVehicle.TabIndex = 1;
            this.ButtonVehicle.Text = "Vehicle";
            this.ButtonVehicle.Click += new System.EventHandler(this.ButtonVehicle_Click);
            // 
            // ButtonPlace
            // 
            this.ButtonPlace.Location = new System.Drawing.Point(137, 10);
            this.ButtonPlace.Name = "ButtonPlace";
            this.ButtonPlace.Size = new System.Drawing.Size(57, 20);
            this.ButtonPlace.TabIndex = 2;
            this.ButtonPlace.Text = "Place";
            this.ButtonPlace.Click += new System.EventHandler(this.ButtonPlace_Click);
            // 
            // propertyGrid1
            // 
            this.propertyGrid1.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.propertyGrid1.Location = new System.Drawing.Point(11, 35);
            this.propertyGrid1.Name = "propertyGrid1";
            this.propertyGrid1.Size = new System.Drawing.Size(218, 227);
            this.propertyGrid1.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.propertyGrid1);
            this.Controls.Add(this.ButtonPlace);
            this.Controls.Add(this.ButtonVehicle);
            this.Controls.Add(this.ButtonPerson);
            this.Menu = this.mainMenu1;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "PropertyGridCE Demo";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button ButtonPerson;
        private System.Windows.Forms.Button ButtonVehicle;
        private System.Windows.Forms.Button ButtonPlace;
        private System.Windows.Forms.PropertyGridCE propertyGrid1;
        private System.Windows.Forms.MainMenu mainMenu1;
    }
}

