﻿// *********************************************************************
// PLEASE DO NOT REMOVE THIS DISCLAIMER
//
// PropertyGridCE - By Jaime Olivares
// Article site: http://www.codeproject.com/KB/grid/PropertyGridCE.aspx
// Author site: www.jaimeolivares.com
// License: Code Project Open License (CPOL)
//
// *********************************************************************

using System.Reflection;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Collections.Generic;

namespace System.Windows.Forms
{
    /// <summary>Main custom control class</summary>
    [DesignTimeVisible(true), DesignerCategory("Form")]
    public class PropertyGridCE : UserControl
    {
        #region Related type declarations
        /// <summary>Provides a behaviour to return custom properties for a class</summary>
        public interface ICustomProperties
        {
            /// <summary>
            /// Return custom properties for the inherited class
            /// </summary>
            /// <returns>Array of custom properties</returns>
            PropertyInfo[] GetProperties();
        }
        /// <summary>Enumerates editor styles: modal form or dropdown control</summary>
        public enum EditorStyle { Modal, DropDown }
        /// <summary>Provides a template for controls to behave as custom editors</summary>
        public interface ICustomEditor
        {
            /// <summary>
            /// Fired when edited value was changed
            /// </summary>
            event EventHandler ValueChanged;
            /// <summary>
            /// Returns the editor style
            /// </summary>
            EditorStyle Style { get; }
            /// <summary>
            /// Get or set the edited value
            /// </summary>
            object Value { get; set; }
            /// <summary>
            /// Initializes editor control
            /// </summary>
            /// <param name="rect">Bounds of the right cell in the propertygrid</param>
            void Init(Rectangle rect);
        }
        /// <summary>Helper class to access some WinAPI functions related with ListView controls</summary>
        private class Win32Helper
        {
            private const uint LVM_GETSUBITEMRECT = 4096 + 56;
            private const uint LVM_SETEXTENDEDLISTVIEWSTYLE = 4096 + 54;

            [DllImport("coredll")]
            private static extern int SendMessage(IntPtr inWindow, UInt32 inMsg, int wParam, ref RECT lParam);
            [DllImport("coredll")]
            private static extern int SendMessage(IntPtr inWindow, UInt32 inMsg, uint wParam, uint lParam);

            /// <summary>Replicates a WinAPI's RECT structure</summary>
            [StructLayout(LayoutKind.Sequential)]
            private struct RECT
            {
                public int left;
                public int top;
                public int right;
                public int bottom;
            }

            /// <summary>Return the boundaries of the requested cell in listview control</summary>
            /// <param name="lv">Reference of the System.Windows.Forms.ListView control</param>
            /// <param name="rowIndex">Listview's row index</param>
            /// <param name="columnIndex">Listview's column index</param>
            /// <returns>Rectangle containing boundaries of the requested cell</returns>
            public static Rectangle GetSubItemRect(ListView lv, int rowIndex, int columnIndex)
            {
                RECT lpRect = new RECT();
                lpRect.top = columnIndex;
                lpRect.left = 0;  // flags
                if (SendMessage(lv.Handle, LVM_GETSUBITEMRECT, rowIndex, ref lpRect) == 0)
                    return new Rectangle(0, 0, 0, 0);
                else
                    return Rectangle.FromLTRB(lpRect.left, lpRect.top, lpRect.right, lpRect.bottom);
            }
            /// <summary>Modify listview style</summary>
            /// <param name="lv">Reference of the System.Windows.Forms.ListView control</param>
            /// <param name="style">Value of style/s to modify</param>
            /// <param name="mask">Mask of the style/s to modify</param>
            public static void SetListViewStyle(ListView lv, uint style, uint mask)
            {
                SendMessage(lv.Handle, LVM_SETEXTENDEDLISTVIEWSTYLE, mask, style);
            }
        }
        #endregion

        #region Private Fields
        /// <summary>The main control that simulates a propertygrid</summary>
        private ListView _ListView = null;
        /// <summary>The control or form used to edit a property</summary>
        private Control _InputControl = null;
        /// <summary>Reference to the selected object</summary>
        private object _SelectedObject = null;
        /// <summary>Selected property (row) in propertygrid</summary>
        private PropertyInfo _SelectedProperty = null;

        /// <summary>Foreground color for text in category rows</summary>
        private Color _CategForeColor = SystemColors.WindowText;
        /// <summary>Background color for text in category rows and cell borders</summary>
        private Color _LineColor = SystemColors.ScrollBar;
        /// <summary>Foreground color for text of properties</summary>
        private Color _ViewForeColor = SystemColors.WindowText;
        /// <summary>Background color for text of properties</summary>
        private Color _ViewBackColor = SystemColors.Window;
        #endregion

        #region Properties
        /// <summary>Reference to the selected object</summary>
        /// <remarks>Will cause the propertygrid to display the properties of the new selected object</remarks>
        public object SelectedObject
        {
            set
            {
                _SelectedObject = value;
                UpdateObject();
            }
            get
            {
                return _SelectedObject;
            }
        }
        /// <summary>Foreground color for text in category rows</summary>
        /// <remarks>Will cause a control update</remarks>
        public Color CategoryForeColor
        {
            set
            {
                _CategForeColor = value;
                if (!this.IsDisposed && this.Visible)
                    UpdateObject();
            }
            get
            {
                return _CategForeColor;
            }
        }
        /// <summary>Background color for text in category rows and cell borders</summary>
        /// <remarks>Will cause a control update</remarks>
        public Color LineColor
        {
            set
            {
                _LineColor = value;
                if (!this.IsDisposed && this.Visible)
                    UpdateObject();
            }
            get
            {
                return _LineColor;
            }
        }
        /// <summary>Foreground color for text of properties</summary>
        /// <remarks>Will cause a control update</remarks>
        public Color ViewForeColor
        {
            set
            {
                _ViewForeColor = value;
                if (!this.IsDisposed && this.Visible)
                    UpdateObject();
            }
            get
            {
                return _ViewForeColor;
            }
        }
        /// <summary>Background color for text of properties</summary>
        /// <remarks>Will cause a control update</remarks>
        public Color ViewBackColor
        {
            set
            {
                _ViewBackColor = value;
                if (!this.IsDisposed && this.Visible)
                    UpdateObject();
            }
            get
            {
                return _ViewBackColor;
            }
        }
        /// <remarks>Font for the listview and editor control</remarks>
        public override Font Font
        {
            get
            {
                return base.Font;
            }
            set
            {
                base.Font = value;
                _ListView.Font = value;
            }
        }
        /// <summary>Set the background color for the control</summary>
        public override Color BackColor
        {
            get
            {
                return base.BackColor;
            }
            set
            {
                base.BackColor = value;
                _ListView.BackColor = value;
            }
        }
        #endregion

        #region Constructors
        /// <summary>Default constructor</summary>
        /// <remarks>Creates and configures the contained listview control that simulates the propertygrid</remarks>
        public PropertyGridCE()
        {
            _ListView = new ListView();
            _ListView.Font = this.Font;
            _ListView.View = View.Details;
            _ListView.Parent = this;
            _ListView.Dock = DockStyle.Fill;
            _ListView.Activation = ItemActivation.OneClick;
            _ListView.ForeColor = this.ForeColor;
            _ListView.FullRowSelect = false;
            _ListView.HeaderStyle = ColumnHeaderStyle.None;
            _ListView.ItemActivate += new EventHandler(_ListView_ItemActivate);

            Win32Helper.SetListViewStyle(_ListView, 1, 1);

            ColumnHeader col1 = new ColumnHeader();
            col1.TextAlign = HorizontalAlignment.Left;
            col1.Width = this.Width / 3 - 2;

            ColumnHeader col2 = new ColumnHeader();
            col2.TextAlign = HorizontalAlignment.Left;
            col2.Width = this.Width * 2 / 3 - 2;

            _ListView.Columns.Add(col1);
            _ListView.Columns.Add(col2);

            _ListView.GotFocus += new EventHandler(_InputControl_MustClose);
        }
        #endregion

        #region Controls' Events
        /// <summary>Fires when a property value change is detected in the editor control</summary>
        public event EventHandler PropertyValueChanged;
        /// <summary>Fired when an item is selected, shows the proper editor control</summary>
        /// <param name="sender">not used</param>
        /// <param name="e">not used</param>
        private void _ListView_ItemActivate(object sender, EventArgs e)
        {
            if (_ListView.SelectedIndices.Count == 1)
            {
                int index = _ListView.SelectedIndices[0];

                ListViewItem item = _ListView.Items[index];
                if (item.Tag == null)
                    return;

                _SelectedProperty = (PropertyInfo)item.Tag;
                CloseDropDown();

                Type editor = null;
                bool canWrite = _SelectedProperty.CanWrite;
                if (canWrite)
                {
                    foreach (Attribute attr in _SelectedProperty.GetCustomAttributes(true))
                    {
                        if (attr.Match(ReadOnlyAttribute.Yes))
                            return;
                        else if (attr is CustomEditorAttribute)
                            editor = ((CustomEditorAttribute)attr).EditorType;
                    }
                }

                if (editor == null)
                {
                    Type type = _SelectedProperty.PropertyType;
                    if (type == typeof(string) || type.IsPrimitive)  // Textbox for primitive types
                    {
                        _InputControl = new TextBox();
                        _InputControl.Font = this.Font;
                        _InputControl.Bounds = Win32Helper.GetSubItemRect(_ListView, index, 1);

                        _InputControl.Text = item.SubItems[1].Text;
                        _InputControl.KeyPress += new KeyPressEventHandler(_InputControl_KeyPress);
//                        ((TextBox)_InputControl).TextChanged +=new EventHandler(_InputControl_MustUpdate);
                    }
                    else if (type.IsEnum)  // ComboBox for enumerations
                    {
                        _InputControl = new ComboBox();
                        _InputControl.Font = this.Font;
                        _InputControl.Bounds = Win32Helper.GetSubItemRect(_ListView, index, 1);

                        ((ComboBox)_InputControl).DropDownStyle = ComboBoxStyle.DropDownList;
                        foreach (string s in GetEnumNames(type))
                            ((ComboBox)_InputControl).Items.Add(s);
                        ((ComboBox)_InputControl).SelectedItem = item.SubItems[1].Text;
                        ((ComboBox)_InputControl).SelectedIndexChanged += new EventHandler(_InputControl_MustClose);
                    }
                    else if (type == typeof(DateTime))  // DateTimePicker for DateTime
                    {
                        _InputControl = new DateTimePicker();
                        _InputControl.Font = this.Font;
                        _InputControl.Bounds = Win32Helper.GetSubItemRect(_ListView, index, 1);

                        ((DateTimePicker)_InputControl).Value = DateTime.Parse(item.SubItems[1].Text);
                        ((DateTimePicker)_InputControl).Format = DateTimePickerFormat.Custom;
                        ((DateTimePicker)_InputControl).CustomFormat = CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern + " " + CultureInfo.CurrentCulture.DateTimeFormat.ShortTimePattern;
                        ((DateTimePicker)_InputControl).ValueChanged += new EventHandler(_InputControl_MustUpdate);
                    }
                    else
                    {
                        editor = GetEditorType(_SelectedProperty.PropertyType);
                    }
                }

                if (editor != null)
                {
                    ICustomEditor control = (ICustomEditor)editor.GetConstructor(new Type[] { }).Invoke(null);
                    (control as Control).Font = this.Font;
                    control.Init(Win32Helper.GetSubItemRect(_ListView, index, 1));
                    control.Value = ((PropertyInfo)item.Tag).GetValue(_SelectedObject, null);
                    control.ValueChanged += new EventHandler(_InputControl_MustUpdate);

                    if (control.Style == EditorStyle.DropDown)
                    {
                        _InputControl = control as Control;
                        if (_InputControl.Bottom > this.Height)
                            _InputControl.Top = (this.Height - _InputControl.Height) - 1;
                        if (_InputControl.Right > this.Width)
                            _InputControl.Left = (this.Width - _InputControl.Width) - 1;
                    }
                    else if (control.Style == EditorStyle.Modal)
                    {
                        Form form = control as Form;
                        if (form.ShowDialog() == DialogResult.OK)
                            ((PropertyInfo)item.Tag).SetValue(_SelectedObject, control.Value, null);
                        UpdateObject();
                        _InputControl = null;
                        return;
                    }
                }

                if (_InputControl != null)
                {
                    _InputControl.Visible = true;
                    _InputControl.Enabled = true;
                    this.Controls.Add(_InputControl);

                    _InputControl.BringToFront();
                    _InputControl.Focus();
                    _InputControl.LostFocus += new EventHandler(_InputControl_MustClose);
                }
            }
        }
        /// <summary>Fired when a key is pressed in an editor textbox</summary>
        /// <param name="sender">not used</param>
        /// <param name="e">Contains key pressed</param>
        /// <remarks>If Enter key is pressed, closes the editor and updates the property</remarks>
        private void _InputControl_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                UpdateProperty();
                CloseDropDown();
            }
        }
        /// <summary>Handles event where editor closing and property updating is required</summary>
        /// <param name="sender">not used</param>
        /// <param name="e">not used</param>
        /// <remarks>Can be invoked from several code portions</remarks>
        private void _InputControl_MustClose(object sender, EventArgs e)
        {
            UpdateProperty();
            CloseDropDown();
        }
        /// <summary>Handles event where property updating is required</summary>
        /// <param name="sender">not used</param>
        /// <param name="e">not used</param>
        private void _InputControl_MustUpdate(object sender, EventArgs e)
        {
            UpdateProperty();
        }
        /// <summary>Fired when control is resized, adjust propertygrid column widths</summary>
        /// <param name="e">not used</param>
        /// <remarks>Columns widths are resized proportionaly: 1/3 for first, 2/3 for second</remarks>
        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);

            this._ListView.Columns[0].Width = this.Width * 1 / 3 - 2;
            this._ListView.Columns[1].Width = this.Width * 2 / 3 - 2;
        }
        /// <summary>Enables or disables the control</summary>
        /// <param name="e">not used</param>
        /// <remarks>Editor control is closed, if active</remarks>
        protected override void OnEnabledChanged(EventArgs e)
        {
            this.CloseDropDown();
            this._ListView.Enabled = this.Enabled;
            base.OnEnabledChanged(e);
        }
        /// <summary>Disposes the underlying controls</summary>
        /// <param name="disposing">not used</param>
        /// <remarks>Editor control is closed, if active</remarks>
        protected override void Dispose(bool disposing)
        {
            this.CloseDropDown();
            this._ListView.Dispose();
            base.Dispose(disposing);
        }
        #endregion

        #region Private methods
        /// <summary>Helper function to sort listview items by text</summary>
        /// <param name="item1">First item</param>
        /// <param name="item2">Second item</param>
        /// <returns>Comparison relative value</returns>
        private static int CompareProperties(ListViewItem item1, ListViewItem item2)
        {
            return item1.Text.CompareTo(item2.Text);
        }
        /// <summary>Fills the listview with the properties of the selected object</summary>
        private void UpdateObject()
        {
            if (_SelectedObject == null)
            {
                _ListView.Items.Clear();
                return;
            }
            _SelectedProperty = null;

            PropertyGridCE.ICustomProperties custom = _SelectedObject as PropertyGridCE.ICustomProperties;
            PropertyInfo[] props = (custom == null) ? _SelectedObject.GetType().GetProperties() : custom.GetProperties();

            SortedList<string, List<ListViewItem>> categories = new SortedList<string, List<ListViewItem>>();
            foreach (PropertyInfo prop in props)
            {
                try
                {
                    if (prop == null)
                        continue;

                    bool parenthesize = false;
                    bool browse = true;
                    string dispname = prop.Name;
                    string category = "";

                    foreach (Attribute attr in prop.GetCustomAttributes(false))
                    {
                        if (attr.GetType() == typeof(ParenthesizePropertyNameAttribute))
                            parenthesize = ((ParenthesizePropertyNameAttribute)attr).NeedParenthesis;
                        else if (attr.GetType() == typeof(BrowsableAttribute))
                            browse = ((BrowsableAttribute)attr).Browsable;
                        else if (attr.GetType() == typeof(DisplayNameAttribute))
                            dispname = ((DisplayNameAttribute)attr).DisplayName;
                        else if (attr.GetType() == typeof(CategoryAttribute))
                            category = ((CategoryAttribute)attr).Category;
                    }

                    if (!browse)
                        continue;

                    if (parenthesize)
                        dispname = "(" + dispname + ")";

                    ListViewItem item = new ListViewItem(dispname);
                    object val = prop.GetValue(_SelectedObject, null);
                    item.SubItems.Add(val == null ? "" : val.ToString());
                    item.Tag = prop;
                    item.ForeColor = this._ViewForeColor;
                    item.BackColor = this._ViewBackColor;

                    if (!categories.ContainsKey(category))
                        categories.Add(category, new List<ListViewItem>());
                    categories[category].Add(item);
                }
                catch
                {
                }
            }

            _ListView.BeginUpdate();
            _ListView.Items.Clear();
            foreach (KeyValuePair<string, List<ListViewItem>> items in categories)
            {
                items.Value.Sort(CompareProperties);

                ListViewItem itemCateg = new ListViewItem(items.Key);
                itemCateg.ForeColor = this._CategForeColor;
                itemCateg.BackColor = this._LineColor;
                _ListView.Items.Add(itemCateg);

                foreach (ListViewItem item in items.Value)
                    _ListView.Items.Add(item);
            }
            _ListView.EndUpdate();
        }
        /// <summary>Updates the value of the selected and edited property in the selected object</summary>
        private void UpdateProperty()
        {
            if (_SelectedProperty == null || _SelectedObject == null)
                return;

            Type type = _SelectedProperty.PropertyType;
            Type editor = GetEditorType(type);
            
            if (editor == null)
            {
                if (type == typeof(string))
                {
                    try
                    {
                        _SelectedProperty.SetValue(_SelectedObject, _InputControl.Text, null);
                        if (this.PropertyValueChanged != null)
                            this.Invoke(this.PropertyValueChanged);
                    }
                    catch { }
                }
                else if (type.IsPrimitive)  // textbox
                {
                    object val;
                    try
                    {
                        val = Convert.ChangeType(_InputControl.Text, type, CultureInfo.InvariantCulture);
                    }
                    catch
                    {
                        val = Convert.ChangeType((uint)0, type, CultureInfo.InvariantCulture);
                    }
                    try
                    {
                        _SelectedProperty.SetValue(_SelectedObject, val, null);
                        if (this.PropertyValueChanged != null)
                            this.Invoke(this.PropertyValueChanged);
                    }
                    catch { }
                }
                else if (type.IsEnum)  // combobox
                {
                    if (_InputControl is ComboBox)
                    {
                        try
                        {
                            object val = Enum.Parse(type, ((ComboBox)_InputControl).SelectedItem.ToString(), false);
                            _SelectedProperty.SetValue(_SelectedObject, val, null);
                            if (this.PropertyValueChanged != null)
                                this.Invoke(this.PropertyValueChanged);
                        }
                        catch { }
                    }
                }
                else   // custom control
                {
                    editor = GetEditorType(type);
                }
            }

            if (editor != null)
            {
                ICustomEditor custom = _InputControl as ICustomEditor;
                if (custom != null)
                {
                    _SelectedProperty.SetValue(_SelectedObject, custom.Value, null);
                    if (this.PropertyValueChanged != null)
                        this.Invoke(this.PropertyValueChanged);
                }
            }

            UpdateObject();
        }
        /// <summary>Search for the CustomEditor attribute for the supplied type</summary>
        /// <param name="_type">Type to evaluate</param>
        /// <returns>Editor type, or null if not defined</returns>
        private Type GetEditorType(Type _type)
        {
            object[] attrs = _type.GetCustomAttributes(typeof(CustomEditorAttribute), false);
            if (attrs.Length == 0)
                return null;
            else
                return ((CustomEditorAttribute)attrs[0]).EditorType;
        }
        /// <summary>Closes the editor control, if active, and updates the selected property's value</summary>
        private void CloseDropDown()
        {
            if (this._InputControl != null)
            {
                this.UpdateProperty();
                this._InputControl.Dispose();
                this._InputControl = null;
            }
        }
        /// <summary>Replicates the .net Framework Enum.GetNames() static method</summary>
        /// <param name="_enum">Enum type to evaluate</param>
        /// <returns>Array of names of the enumerated elements</returns>
        private static string[] GetEnumNames(Type _enum)
        {
            FieldInfo[] infos = _enum.GetFields(BindingFlags.Public | BindingFlags.Static);
            string[] ret = new string[infos.Length];
            for (int i = 0; i < ret.Length; i++)
                ret[i] = infos[i].Name;
            return ret;
        }
        #endregion
    }
}

namespace System.ComponentModel
{
    /// <summary>Determines if the property should be shown on propertygrid</summary>
    [AttributeUsage(AttributeTargets.All)]
    public sealed class BrowsableAttribute : Attribute
    {
        public bool Browsable { get; set; }
        public static readonly BrowsableAttribute Yes = new BrowsableAttribute(true);
        public static readonly BrowsableAttribute No = new BrowsableAttribute(false);

        public BrowsableAttribute(bool _browsable) { Browsable = _browsable; }
        public override bool Match(object obj)
        {
            if (obj is BrowsableAttribute)
                return this.Browsable = (obj as BrowsableAttribute).Browsable;
            return base.Match(obj);
        }
    }

    /// <summary>Describes the name of the property's category</summary>
    [AttributeUsage(AttributeTargets.All)]
    public sealed class CategoryAttribute : Attribute
    {
        public string Category { get; set; }

        public CategoryAttribute(string _category) { Category = _category; }
    }

    /// <summary>Determines if the property name must be displayed between parenthesis</summary>
    [AttributeUsage(AttributeTargets.All)]
    public sealed class ParenthesizePropertyNameAttribute : Attribute
    {
        public bool NeedParenthesis { get; set; }

        public ParenthesizePropertyNameAttribute(bool _need) { NeedParenthesis = _need; }
    }

    /// <summary>Replaces the default property name</summary>
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method | AttributeTargets.Property | AttributeTargets.Event)]
    public sealed class DisplayNameAttribute : Attribute
    {
        public string DisplayName { get; set; }

        public DisplayNameAttribute(string _displayname) { DisplayName = _displayname; }
    }

    /// <summary>Determines the custom editor control</summary>
    /// <remarks>The editor control must inherit the PropertyGridCE.ICustomEditor interface</remarks>
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct | AttributeTargets.Property)]
    public sealed class CustomEditorAttribute : Attribute
    {
        public Type EditorType { get; set; }

        public CustomEditorAttribute(Type _editor)
        {
            this.EditorType = _editor;
        }
    }

    /// <summary>Determines if the property will be read-only or not</summary>
    [AttributeUsage(AttributeTargets.All)]
    public sealed class ReadOnlyAttribute : Attribute
    {
        public bool IsReadOnly { get; private set; }
        public static readonly ReadOnlyAttribute No = new ReadOnlyAttribute(false);
        public static readonly ReadOnlyAttribute Yes = new ReadOnlyAttribute(true);

        public ReadOnlyAttribute(bool isReadOnly)
        {
            this.IsReadOnly = isReadOnly;
        }
        public override bool Match(object obj)
        {
            if (obj is ReadOnlyAttribute)
                return this.IsReadOnly = (obj as ReadOnlyAttribute).IsReadOnly;
            return base.Match(obj);
        }
    }
}
